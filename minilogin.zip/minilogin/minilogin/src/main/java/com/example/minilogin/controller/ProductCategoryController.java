package com.example.minilogin.controller;

public class ProductCategoryController {

}
