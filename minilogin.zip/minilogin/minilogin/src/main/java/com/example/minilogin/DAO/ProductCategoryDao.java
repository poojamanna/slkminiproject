package com.example.minilogin.DAO;

public interface ProductCategoryDao {

}
